<?php

namespace App\Filament\Pimpinan\Resources\BalitaResource\Pages;

use App\Filament\Pimpinan\Resources\BalitaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBalita extends CreateRecord
{
    protected static string $resource = BalitaResource::class;
}
