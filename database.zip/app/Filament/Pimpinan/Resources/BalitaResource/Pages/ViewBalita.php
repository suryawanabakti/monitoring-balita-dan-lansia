<?php

namespace App\Filament\Pimpinan\Resources\BalitaResource\Pages;

use App\Filament\Pimpinan\Resources\BalitaResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewBalita extends ViewRecord
{
    protected static string $resource = BalitaResource::class;
}
