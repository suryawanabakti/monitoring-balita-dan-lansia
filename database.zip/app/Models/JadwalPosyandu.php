<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JadwalPosyandu extends Model
{
    public $table = 'jadwal_posyandu';
    protected $guarded = ['id'];
}
