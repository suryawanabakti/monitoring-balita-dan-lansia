<!-- resources/views/filament/header.blade.php -->
<div class="flex items-center">
    {{-- <img src="{{ asset('path/to/your-image.png') }}" alt="Logo" class="h-12 w-12 mr-2"> --}}
    <h1 class="text-2xl font-semibold">Welcome to Admin Panel</h1>
</div>
