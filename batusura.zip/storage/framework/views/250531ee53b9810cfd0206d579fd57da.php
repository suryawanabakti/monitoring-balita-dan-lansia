<h3
    <?php echo e($attributes->class(['fi-section-header-heading text-base font-semibold leading-6 text-gray-950 dark:text-white'])); ?>>
    <?php echo e($slot); ?>

</h3>
<?php /**PATH C:\Users\Pongo\Herd\SKRIPSIKU\monitoring-balita-dan-lansia\resources\views/vendor/filament/components/section/heading.blade.php ENDPATH**/ ?>