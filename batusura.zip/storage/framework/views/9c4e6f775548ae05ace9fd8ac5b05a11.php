

<table border="1" cellspacing="0" cellpadding="5" width="100%">
    <thead>
        <tr>
            <th>Tanggal Pemeriksaan</th>
            <th>Nama Balita</th>
            <th>BB (kg)</th>
            <th>TPPB</th>
            <th>LILA (cm)</th>
            <th>ASI Eksklusif</th>
            <th>Vitamin A</th>
            <th>Umur</th>
            <th>PMT Ke</th>
            <th>BGT BGM</th>
            <th>IMD</th>
            <th>Catatan</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($d->tgl_pemeriksaan); ?></td>
                <td><?php echo e($d->balita->nama); ?></td>
                <td><?php echo e($d->berat_badan); ?></td>
                <td><?php echo e($d->tppb); ?></td>
                <td><?php echo e($d->lingkar_kepala); ?></td>
                <td><?php echo e($d->asi_ekslusif ? 'Iya' : 'Tidak'); ?></td>
                <td><?php echo e($d->vit_a ? 'Iya' : 'Tidak'); ?></td>
                <td><?php echo e($d->umur); ?></td>
                <td><?php echo e($d->pmt_ke); ?></td>
                <td><?php echo e($d->bgt_bgm); ?></td>
                <td><?php echo e($d->imd ? 'Iya' : 'Tidak'); ?></td>
                <td><?php echo e($d->catatan); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\Pongo\Herd\monitoring-balita-dan-lansia\resources\views/export/balita.blade.php ENDPATH**/ ?>