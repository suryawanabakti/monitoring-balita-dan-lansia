<?php

namespace App\Filament\Wali\Resources\LansiaResource\Pages;

use App\Filament\Wali\Resources\LansiaResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewLansia extends ViewRecord
{
    protected static string $resource = LansiaResource::class;
}
