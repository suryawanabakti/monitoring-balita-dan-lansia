<?php

namespace App\Filament\Wali\Resources\JadwalPosyanduResource\Pages;

use App\Filament\Wali\Resources\JadwalPosyanduResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateJadwalPosyandu extends CreateRecord
{
    protected static string $resource = JadwalPosyanduResource::class;
}
