<?php

namespace App\Filament\Resources\JadwalPosyanduResource\Pages;

use App\Filament\Resources\JadwalPosyanduResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateJadwalPosyandu extends CreateRecord
{
    protected static string $resource = JadwalPosyanduResource::class;
}
