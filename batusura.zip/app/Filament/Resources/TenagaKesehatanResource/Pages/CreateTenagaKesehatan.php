<?php

namespace App\Filament\Resources\TenagaKesehatanResource\Pages;

use App\Filament\Resources\TenagaKesehatanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTenagaKesehatan extends CreateRecord
{
    protected static string $resource = TenagaKesehatanResource::class;
}
