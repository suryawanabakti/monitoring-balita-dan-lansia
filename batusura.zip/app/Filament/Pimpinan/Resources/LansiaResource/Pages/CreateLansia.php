<?php

namespace App\Filament\Pimpinan\Resources\LansiaResource\Pages;

use App\Filament\Pimpinan\Resources\LansiaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLansia extends CreateRecord
{
    protected static string $resource = LansiaResource::class;
}
